export * from "./registerPersonalizationObjects";
